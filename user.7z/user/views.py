from django.shortcuts import render
from django.views.generic import CreateView
from django.contrib.auth.forms import AuthenticationForm

# Create your views here.

class LoginView(CreateView):
    form_class = AuthenticationForm
    template_name = 'login.html'